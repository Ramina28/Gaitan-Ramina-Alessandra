<?php

session_start();

// DB
$host = "mysql";
$dbname = "studenti";   // dacă tu folosești alt nume, schimbă aici
$user = "user";
$pass = "password";

// Admin (simplu)
const ADMIN_USER = "admin";
const ADMIN_PASS = "admin123"; 

function redirectWithError($msg) {
    header("Location: login.html?err=" . urlencode($msg));
    exit;
}

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    redirectWithError("Eroare DB: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: login.html");
    exit;
}

$tip = $_POST["tip"] ?? "";

if ($tip === "utilizator") {
    $nume = trim($_POST["nume"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $telefon = trim($_POST["telefon"] ?? "");

    if ($nume === "" || $email === "" || $telefon === "") {
        redirectWithError("Completează nume, email și telefon.");
    }

    // dacă email există => luăm id, altfel inserăm
    $stmt = $pdo->prepare("SELECT id FROM utilizatori WHERE email = ?");
    $stmt->execute([$email]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($u) {
        $id_utilizator = (int)$u["id"];
    } else {
        $stmt = $pdo->prepare("INSERT INTO utilizatori (nume, email, telefon) VALUES (?, ?, ?)");
        $stmt->execute([$nume, $email, $telefon]);
        $id_utilizator = (int)$pdo->lastInsertId();
    }

    $_SESSION["user_role"] = "utilizator";
    $_SESSION["user_id"] = $id_utilizator;
    $_SESSION["login_time"] = time(); 

    // deschide pagina principală (NU o schimbăm)
    header("Location: PaginaPrincipala.php");
    exit;
}

if ($tip === "admin") {
    $admin_user = trim($_POST["admin_user"] ?? "");
    $admin_pass = trim($_POST["admin_pass"] ?? "");

    if ($admin_user === ADMIN_USER && $admin_pass === ADMIN_PASS) {
        $_SESSION["user_role"] = "admin";
        $_SESSION["login_time"] = time();
        header("Location: rezervari_admin.php");
        exit;
    }

    redirectWithError("User/parolă admin greșite.");
}

redirectWithError("Alege Utilizator sau Admin.");
