<?php

$TIMEOUT_SECONDS = 3600; // 1 oră

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => $TIMEOUT_SECONDS,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// verificare expirare
if (isset($_SESSION['LAST_ACTIVITY']) && time() - $_SESSION['LAST_ACTIVITY'] > $TIMEOUT_SECONDS) {
    session_unset();
    session_destroy();
    header("Location: logout.php?msg=" . urlencode("Sesiunea a expirat după 1 oră de inactivitate."));
    exit;
}

// actualizare activitate
$_SESSION['LAST_ACTIVITY'] = time();

// protecție login
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html?err=" . urlencode("Trebuie să te loghezi pentru a continua."));
    exit;
}
// ================================
// 1. Conectare la baza de date
// ================================
$host = "mysql";
$dbname = "studenti";   // sau Gaitan_Ramina
$user = "user";
$pass = "password";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Eroare conectare: " . $e->getMessage());
}

// ================================
// 2. Procesare formular
// ================================
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nume    = trim($_POST["nume"] ?? "");
    $email   = trim($_POST["email"] ?? "");
    $telefon = trim($_POST["telefon"] ?? "");
    $mesaj   = trim($_POST["mesaj"] ?? "");

    if ($nume === "" || $email === "" || $telefon === "" || $mesaj === "") {
        die("Te rog completează toate câmpurile.");
    }

    // id_utilizator este OBLIGATORIU
    $id_utilizator = (int)$_SESSION["user_id"];

    // ================================
    // 3. Inserăm mesajul
    // ================================
    $stmt = $pdo->prepare("
        INSERT INTO contact (id_utilizator, nume_complet, email, telefon, mesaj)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$id_utilizator, $nume, $email, $telefon, $mesaj]);

    echo "<script>alert('Mesaj trimis cu succes!'); window.location.href='contact.html';</script>";
    exit;
}

echo "Acces invalid.";
?>
