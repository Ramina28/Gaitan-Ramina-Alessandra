<?php
session_start();

// ============================
// 0) Protecție + timeout
// ============================
$SESSION_TIMEOUT = 3 * 24 * 60 * 60; // 3 zile

if (!isset($_SESSION["user_role"]) || $_SESSION["user_role"] !== "admin") {
    header("Location: login.html?err=" . urlencode("Nu ai acces. Loghează-te ca admin."));
    exit;
}

if (!isset($_SESSION["login_time"])) {
    session_destroy();
    header("Location: login.html?err=" . urlencode("Sesiune invalidă. Te rugăm să te loghezi din nou."));
    exit;
}

if (time() - $_SESSION["login_time"] > $SESSION_TIMEOUT) {
    session_destroy();
    header("Location: login.html?err=" . urlencode("Sesiunea a expirat. Te rugăm să te loghezi din nou."));
    exit;
}

// (opțional) refresh la timp ca să nu expire dacă lucrezi
$_SESSION["login_time"] = time();

// ============================
// 1) DB
// ============================
$host = "mysql";
$dbname = "studenti";
$user = "user";
$pass = "password";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Eroare DB: " . $e->getMessage());
}

$msg = "";

// ============================
// 2) DELETE rezervare
// ============================
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "delete") {
    $id = (int)($_POST["id"] ?? 0);

    if ($id > 0) {
        $stmt = $pdo->prepare("DELETE FROM rezervari WHERE id = ?");
        $stmt->execute([$id]);
        $msg = "Rezervarea #$id a fost ștearsă.";
    }
}

// ============================
// 3) ADD rezervare (admin)
// ============================
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "add") {
    $id_utilizator = (int)($_POST["id_utilizator"] ?? 0);
    $joc  = trim($_POST["joc"] ?? "");
    $data = trim($_POST["data"] ?? "");
    $ora  = trim($_POST["ora"] ?? "");

    if ($id_utilizator <= 0 || $joc === "" || $data === "" || $ora === "") {
        $msg = "Completează toate câmpurile pentru adăugare (inclusiv ID utilizator).";
    } else {
        // verificăm că utilizatorul există
        $stmt = $pdo->prepare("SELECT id FROM utilizatori WHERE id = ?");
        $stmt->execute([$id_utilizator]);
        if (!$stmt->fetch()) {
            $msg = "Nu există utilizator cu ID = $id_utilizator.";
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO rezervari (id_utilizator, joc, data_rezervare, ora)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$id_utilizator, $joc, $data, $ora]);
            $msg = "Rezervare adăugată cu succes.";
        }
    }
}

// ============================
// 4) Listare rezervări
// ============================
$sql = "
  SELECT r.id,
         u.id AS user_id,
         u.nume, u.email, u.telefon,
         r.joc, r.data_rezervare, r.ora,
         r.data_creare
  FROM rezervari r
  JOIN utilizatori u ON r.id_utilizator = u.id
  ORDER BY r.data_rezervare DESC, r.ora DESC
";
$rezervari = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

// listă utilizatori pentru dropdown (ca admin să adauge mai ușor)
$users = $pdo->query("SELECT id, nume, email FROM utilizatori ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin - Rezervări</title>
  <link rel="stylesheet" href="admin.css" />
</head>
<body>

<header class="topbar">
  <div class="top-left">
    <h1>Admin</h1>
    <nav class="admin-nav">
      <a class="nav-link active" href="rezervari_admin.php">Rezervări</a>
      <a class="nav-link" href="contacte_admin.php">Mesaje Contact</a>
    </nav>
  </div>

  <div class="actions">
    <a class="btn" href="logout.php">Logout</a>
  </div>
</header>

<main class="container">

  <?php if ($msg !== ""): ?>
    <div class="notice"><?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <section class="card">
    <h2>Adaugă rezervare (admin)</h2>

    <form method="post" class="form-grid">
      <input type="hidden" name="action" value="add">

      <label>
        Utilizator (alege din listă)
        <select name="id_utilizator" required>
          <option value="">-- alege utilizator --</option>
          <?php foreach ($users as $u): ?>
            <option value="<?= (int)$u["id"] ?>">
              #<?= (int)$u["id"] ?> - <?= htmlspecialchars($u["nume"]) ?> (<?= htmlspecialchars($u["email"]) ?>)
            </option>
          <?php endforeach; ?>
        </select>
      </label>

      <label>
        Joc
        <select name="joc" required>
          <option value="">-- alege joc --</option>
          <option value="biliard">Biliard</option>
          <option value="bowling">Bowling</option>
          <option value="pingpong">Ping Pong</option>
          <option value="catarari">Cățărări</option>
          <option value="minigolf">Minigolf</option>
        </select>
      </label>

      <label>
        Data
        <input type="date" name="data" required>
      </label>

      <label>
        Ora
        <input type="time" name="ora" required>
      </label>

      <button class="btn primary" type="submit">Adaugă</button>
    </form>
  </section>

  <p class="meta">Total rezervări: <strong><?= count($rezervari) ?></strong></p>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>ID Utilizator</th>
          <th>Nume</th>
          <th>Email</th>
          <th>Telefon</th>
          <th>Joc</th>
          <th>Data</th>
          <th>Ora</th>
          <th>Creat la</th>
          <th>Acțiuni</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($rezervari)): ?>
          <tr><td colspan="10">Nu există rezervări.</td></tr>
        <?php else: ?>
          <?php foreach ($rezervari as $r): ?>
            <tr>
              <td><?= htmlspecialchars($r["id"]) ?></td>
              <td><?= htmlspecialchars($r["user_id"]) ?></td>
              <td><?= htmlspecialchars($r["nume"]) ?></td>
              <td><?= htmlspecialchars($r["email"]) ?></td>
              <td><?= htmlspecialchars($r["telefon"]) ?></td>
              <td><?= htmlspecialchars($r["joc"]) ?></td>
              <td><?= htmlspecialchars($r["data_rezervare"]) ?></td>
              <td><?= htmlspecialchars($r["ora"]) ?></td>
              <td><?= htmlspecialchars($r["data_creare"] ?? "") ?></td>
              <td>
                <form method="post" class="inline" onsubmit="return confirm('Sigur vrei să ștergi rezervarea #<?= (int)$r['id'] ?> ?');">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?= (int)$r["id"] ?>">
                  <button class="btn danger" type="submit">Șterge</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

</main>

</body>
</html>
