<?php

$TIMEOUT_SECONDS = 3600; // 1 oră

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => $TIMEOUT_SECONDS,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// verificare expirare
if (isset($_SESSION['LAST_ACTIVITY']) && time() - $_SESSION['LAST_ACTIVITY'] > $TIMEOUT_SECONDS) {
    session_unset();
    session_destroy();
    header("Location: logout.php?msg=" . urlencode("Sesiunea a expirat după 1 oră de inactivitate."));
    exit;
}

// actualizare activitate
$_SESSION['LAST_ACTIVITY'] = time();

// protecție login
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html?err=" . urlencode("Trebuie să te loghezi pentru a continua."));
    exit;
}

// DB
$host   = "mysql";
$dbname = "studenti";
$user   = "user";
$pass   = "password";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("Eroare conectare la baza de date: " . $e->getMessage());
}

// info utilizator din DB (pe baza user_id din sesiune)
$id_utilizator = (int)$_SESSION["user_id"];
$stmtU = $pdo->prepare("SELECT nume, email, telefon FROM utilizatori WHERE id = ?");
$stmtU->execute([$id_utilizator]);
$util = $stmtU->fetch() ?: ["nume"=>"", "email"=>"", "telefon"=>""];

// detectăm abonamentul selectat (din URL)
$showForm = false;
$selJoc = $selDurata = $selPret = "";

if (isset($_GET["joc"], $_GET["durata"], $_GET["pret"])) {
    $showForm = true;
    $selJoc    = trim($_GET["joc"]);
    $selDurata = trim($_GET["durata"]);
    $selPret   = trim($_GET["pret"]);
}

// procesare confirmare achiziție (POST)
$successMsg = "";
$errorMsg = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["confirma"])) {
    $joc    = trim($_POST["joc"] ?? "");
    $durata = trim($_POST["durata"] ?? "");
    $pret   = trim($_POST["pret"] ?? "");

    if ($joc === "" || $durata === "" || $pret === "") {
        $errorMsg = "Abonament invalid. Reîncearcă.";
        $showForm = false;
    } else {
        // (opțional) verificare minimă preț numeric
        $pretNum = (float)$pret;

        // salvăm cererea în DB
        $ins = $pdo->prepare("
            INSERT INTO achizitii_abonamente
              (id_utilizator, nume, email, telefon, joc, durata, pret)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $ins->execute([
            $id_utilizator,
            $util["nume"],
            $util["email"],
            $util["telefon"],
            $joc,
            $durata,
            $pretNum
        ]);

        $successMsg = "Achiziția a fost înregistrată! Vei fi contactat/ă pentru confirmare.";
        $showForm = false;
    }
}

// funcție afișare abonamente + buton hover
function afiseazaAbonamente(PDO $pdo, string $joc): void {
    try {
        $stmt = $pdo->prepare("SELECT durata, pret FROM abonamente WHERE joc = ? ORDER BY id ASC");
        $stmt->execute([$joc]);
        $rows = $stmt->fetchAll();

        if (!$rows) {
            echo "<tr><td colspan='3'>Nu există abonamente pentru acest joc.</td></tr>";
            return;
        }

        foreach ($rows as $row) {
            $durata = (string)$row["durata"];
            $pret   = (string)$row["pret"];

            $href = "abonamente.php?joc=" . urlencode($joc)
                  . "&durata=" . urlencode($durata)
                  . "&pret=" . urlencode($pret);

            echo "<tr class='abon-row'>";
            echo "<td>" . htmlspecialchars($durata) . "</td>";
            echo "<td>" . htmlspecialchars($pret) . " RON</td>";
            echo "<td class='act'><a class='btn-buy' href='" . htmlspecialchars($href) . "'>Achiziționează</a></td>";
            echo "</tr>";
        }
    } catch (PDOException $e) {
        echo "<tr><td colspan='3'>Eroare: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
    }
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Abonamente Centrul de Agrement</title>
    <link rel="stylesheet" href="abonamente.css?v=2">
</head>

<body>

<button id="btnTop" title="Înapoi sus">↑</button>

<a href="PaginaPrincipala.php" class="buton-inapoi">←</a>

<header>
    <h1>Abonamente Centrul de Agrement</h1>
</header>

<?php if ($successMsg): ?>
  <div class="buy-wrap">
    <div class="buy-card">
      <p class="msg-ok"><?= htmlspecialchars($successMsg) ?></p>
      <a class="link-back" href="abonamente.php">← Înapoi la listă</a>
    </div>
  </div>
<?php endif; ?>

<?php if ($showForm): ?>
<div class="buy-wrap">
  <div class="buy-card">
    <h2>Confirmă achiziția</h2>

    <?php if ($errorMsg): ?>
      <p class="msg-err"><?= htmlspecialchars($errorMsg) ?></p>
    <?php endif; ?>

    <div class="summary">
      <div><b>Joc:</b> <?= htmlspecialchars($selJoc) ?></div>
      <div><b>Durată:</b> <?= htmlspecialchars($selDurata) ?></div>
      <div><b>Preț:</b> <?= htmlspecialchars($selPret) ?> RON</div>
    </div>

    <div class="summary">
      <div><b>Nume:</b> <?= htmlspecialchars($util["nume"]) ?></div>
      <div><b>Email:</b> <?= htmlspecialchars($util["email"]) ?></div>
      <div><b>Telefon:</b> <?= htmlspecialchars($util["telefon"]) ?></div>
    </div>

    <form method="post" action="abonamente.php" class="buy-form">
      <input type="hidden" name="confirma" value="1">
      <input type="hidden" name="joc" value="<?= htmlspecialchars($selJoc) ?>">
      <input type="hidden" name="durata" value="<?= htmlspecialchars($selDurata) ?>">
      <input type="hidden" name="pret" value="<?= htmlspecialchars($selPret) ?>">

      <button class="btn-pay" type="submit">Confirmă achiziția</button>
    </form>

    <a class="link-back" href="abonamente.php">← Înapoi la listă</a>
  </div>
</div>
<?php endif; ?>

<div class="container">
    <h2>Biliard</h2>
    <table class="abon-table">
        <tr><th>Durată</th><th>Preț</th><th class="th-act">Acțiune</th></tr>
        <?php afiseazaAbonamente($pdo, "Biliard"); ?>
    </table>

    <h2>Bowling</h2>
    <table class="abon-table">
        <tr><th>Durată</th><th>Preț</th><th class="th-act">Acțiune</th></tr>
        <?php afiseazaAbonamente($pdo, "Bowling"); ?>
    </table>

    <h2>Minigolf</h2>
    <table class="abon-table">
        <tr><th>Durată</th><th>Preț</th><th class="th-act">Acțiune</th></tr>
        <?php afiseazaAbonamente($pdo, "Minigolf"); ?>
    </table>

    <h2>Cățărare</h2>
    <table class="abon-table">
        <tr><th>Durată</th><th>Preț</th><th class="th-act">Acțiune</th></tr>
        <?php afiseazaAbonamente($pdo, "Cățărare"); ?>
    </table>

    <h2>Ping Pong</h2>
    <table class="abon-table">
        <tr><th>Durată</th><th>Preț</th><th class="th-act">Acțiune</th></tr>
        <?php afiseazaAbonamente($pdo, "Ping Pong"); ?>
    </table>
</div>

<script src="main.js"></script>
</body>
</html>
