<?php

$TIMEOUT_SECONDS = 3600; // 1 oră

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => $TIMEOUT_SECONDS,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// verificare expirare
if (isset($_SESSION['LAST_ACTIVITY']) && time() - $_SESSION['LAST_ACTIVITY'] > $TIMEOUT_SECONDS) {
    session_unset();
    session_destroy();
    header("Location: logout.php?msg=" . urlencode("Sesiunea a expirat după 1 oră de inactivitate."));
    exit;
}

// actualizare activitate
$_SESSION['LAST_ACTIVITY'] = time();

// protecție login
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html?err=" . urlencode("Trebuie să te loghezi pentru a continua."));
    exit;
}
?>
<!DOCTYPE html>
<html lang="ro">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Centrul de Agrement FunZone</title>
    <link rel="stylesheet" href="pagina_principala.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">

</head>

<button id="btnTop" title="Înapoi sus">↑</button>

<body>

    <header>
        <nav class="navbar">
            <div class="logo">Centrul de Agrement</div>
            <ul class="nav-links">
                <li><a href="tarife.html">Tarife</a></li>
                <li><a href="rezervari.php">Rezervări</a></li>
                <li><a href="jocuri.html">Jocuri</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="abonamente.php">Abonamente</a></li>
            </ul>
        </nav>
        <div class="hero">
            <h1>Bine ați venit la Centrul de Agrement!</h1>
            <p>Descoperă distracția la biliard, bowling, ping-pong, minigolf și cățărare într-un singur loc.</p>
        </div>
    </header>
    <div class="content-grid"></div>
    <main>
        <section class="descriere">
            <h2>Despre noi</h2>
            <p>
                Centrul nostru de agrement este locul perfect pentru relaxare și distracție în familie sau cu prietenii. Oferim o gamă variată de jocuri și activități, de la bowling și biliard la minigolf și cățărare. Vino să petreci timp de calitate și să creezi amintiri
                de neuitat!
            </p>
        </section>
    </main>

    <aside>
        <h3>Oferte speciale</h3>
        <ul>
            <li>🎳 Turneu de bowling în weekend</li>
            <li>🏓 Reducere pentru grupuri de elevi</li>
            <li>🎯 Abonamente cu 10% reducere</li>
        </ul>
    </aside>

    </div>

    <footer>
        <p>&copy; 2025 Centrul de Agrement FunZone | Toate drepturile rezervate</p>
    </footer>

    <script src="main.js"></script>
</body>

</html>