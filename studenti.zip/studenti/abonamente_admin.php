<?php

$TIMEOUT_SECONDS = 3600; // 1 oră

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => $TIMEOUT_SECONDS,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// verificare expirare
if (isset($_SESSION['LAST_ACTIVITY']) && time() - $_SESSION['LAST_ACTIVITY'] > $TIMEOUT_SECONDS) {
    session_unset();
    session_destroy();
    header("Location: logout.php?msg=" . urlencode("Sesiunea a expirat după 1 oră de inactivitate."));
    exit;
}

// actualizare activitate
$_SESSION['LAST_ACTIVITY'] = time();

// protecție login
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html?err=" . urlencode("Trebuie să te loghezi pentru a continua."));
    exit;
}

// DB
$host   = "mysql";
$dbname = "studenti";
$user   = "user";
$pass   = "password";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("Eroare DB: " . $e->getMessage());
}

$msgOk = "";
$msgErr = "";

/* =========================
   UPDATE PREȚ ABONAMENT
   ========================= */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["update_pret"])) {
    $id   = (int)($_POST["id"] ?? 0);
    $pret = trim($_POST["pret"] ?? "");

    if ($id <= 0 || $pret === "" || !is_numeric($pret) || (float)$pret < 0) {
        $msgErr = "Preț invalid.";
    } else {
        $stmt = $pdo->prepare("UPDATE abonamente SET pret = ? WHERE id = ?");
        $stmt->execute([(float)$pret, $id]);
        $msgOk = "Preț actualizat cu succes!";
    }
}

/* =========================
   ȘTERGE ABONAMENT
   ========================= */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["sterge_abonament"])) {
    $id = (int)($_POST["id"] ?? 0);
    if ($id > 0) {
        $del = $pdo->prepare("DELETE FROM abonamente WHERE id = ?");
        $del->execute([$id]);
        $msgOk = "Abonament șters.";
    }
}

/* =========================
   ADAUGĂ ABONAMENT
   ========================= */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["adauga_abonament"])) {
    $joc    = trim($_POST["joc"] ?? "");
    $durata = trim($_POST["durata"] ?? "");
    $pret   = trim($_POST["pret"] ?? "");

    if ($joc === "" || $durata === "" || $pret === "" || !is_numeric($pret) || (float)$pret < 0) {
        $msgErr = "Completează corect joc/durată/preț.";
    } else {
        $ins = $pdo->prepare("INSERT INTO abonamente (joc, durata, pret) VALUES (?, ?, ?)");
        $ins->execute([$joc, $durata, (float)$pret]);
        $msgOk = "Abonament adăugat!";
    }
}

/* =========================
   DATE: ABONAMENTE
   ========================= */
$abonamente = $pdo->query("SELECT id, joc, durata, pret FROM abonamente ORDER BY joc ASC, id ASC")->fetchAll();

/* =========================
   DATE: ACHIZIȚII ABONAMENTE
   ========================= */
$achizitii = [];
try {
    $achizitii = $pdo->query("
        SELECT id, id_utilizator, nume, email, telefon, joc, durata, pret, data_creare
        FROM achizitii_abonamente
        ORDER BY data_creare DESC
    ")->fetchAll();
} catch (PDOException $e) {
    $achizitii = [];
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin - Abonamente</title>
  <link rel="stylesheet" href="admin.css?v=2">

  <style>
    /* Layout general */
    .wrap{max-width:1200px;margin:22px auto;padding:0 16px;}
    .page-title{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:16px 0;}
    .page-title h2{margin:0;font-size:22px;}

    .grid{
      display:grid;
      grid-template-columns: 2fr 1fr; /* stânga mai mare */
      gap:16px;
      align-items:start;
    }
    @media (max-width: 1000px){
      .grid{grid-template-columns:1fr;}
    }

    .card{
      background:#fff;
      border-radius:14px;
      padding:16px;
      box-shadow:0 8px 20px rgba(0,0,0,.08);
    }

    .msg-ok{color:#16a34a;font-weight:800;margin:8px 0 0;}
    .msg-err{color:#dc2626;font-weight:800;margin:8px 0 0;}
    .muted{color:#666;font-size:13px;margin-top:6px;}

    /* Tabele */
    table{width:100%;border-collapse:collapse;}
    th,td{padding:10px;border-bottom:1px solid #eee;text-align:left;vertical-align:top;}
    th{background:#3498db;color:#fff;font-weight:800;white-space:nowrap;}

    .table-scroll{overflow:auto;-webkit-overflow-scrolling:touch;}

    /* Formular adăugare */
    .form-add{
      display:grid;
      grid-template-columns: 1fr 1fr 140px 170px;
      gap:10px;
      align-items:end;
      margin:12px 0 14px;
    }
    @media (max-width: 1000px){
      .form-add{grid-template-columns:1fr;}
    }

    .inp{
      width:100%;
      padding:9px 10px;
      border:1px solid #d0d0d0;
      border-radius:10px;
      box-sizing:border-box;
    }

    .actions{display:flex;gap:8px;align-items:center;}
    .btn{
      border:0;
      border-radius:10px;
      padding:9px 12px;
      cursor:pointer;
      font-weight:800;
      white-space:nowrap;
    }
    .btn-save{background:#16a34a;color:#fff;}
    .btn-save:hover{background:#128043;}
    .btn-del{background:#c0392b;color:#fff;}
    .btn-del:hover{background:#a93226;}
    .btn-add{background:#3498db;color:#fff;}
    .btn-add:hover{background:#2980b9;}

    /* Dreapta: achizitii - facem tabelul vizibil */
    .achizitii-table{
      min-width: 740px; /* forțează scroll orizontal dacă spațiul e mic */
    }
    .nowrap{white-space:nowrap;}
    .cell-small{font-size:13px;color:#222;}
  </style>
</head>
<body>

<!-- TOPBAR (la fel ca în rezervari_admin.php) -->
<header class="topbar">
  <div class="top-left">
    <h1>Admin</h1>
    <nav class="admin-nav">
      <a class="nav-link" href="rezervari_admin.php">Rezervări</a>
      <a class="nav-link" href="contacte_admin.php">Mesaje Contact</a>
      <a class="nav-link active" href="abonamente_admin.php">Abonamente</a>
    </nav>
  </div>
</header>

<div class="wrap">
  <div class="page-title">
    <h2>Administrare abonamente</h2>
  </div>

  <?php if ($msgOk): ?><div class="msg-ok"><?= htmlspecialchars($msgOk) ?></div><?php endif; ?>
  <?php if ($msgErr): ?><div class="msg-err"><?= htmlspecialchars($msgErr) ?></div><?php endif; ?>

  <div class="grid">

    <!-- STÂNGA: ABONAMENTE -->
    <div class="card">
      <h3 style="margin:0 0 6px;">Abonamente (modifică prețul)</h3>
      <div class="muted">Poți adăuga abonamente și poți edita prețul direct pe rând.</div>

      <form class="form-add" method="post">
        <div>
          <label class="cell-small">Joc</label>
          <input class="inp" name="joc" placeholder="Ex: Bowling" required>
        </div>
        <div>
          <label class="cell-small">Durată</label>
          <input class="inp" name="durata" placeholder="Ex: 3 luni" required>
        </div>
        <div>
          <label class="cell-small">Preț (RON)</label>
          <input class="inp" name="pret" placeholder="Ex: 270" required>
        </div>
        <button class="btn btn-add" type="submit" name="adauga_abonament" value="1">Adaugă abonament</button>
      </form>

      <div class="table-scroll">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Joc</th>
              <th>Durată</th>
              <th class="nowrap">Preț (RON)</th>
              <th>Acțiuni</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!$abonamente): ?>
              <tr><td colspan="5">Nu există abonamente.</td></tr>
            <?php else: ?>
              <?php foreach ($abonamente as $a): ?>
                <tr>
                  <td><?= (int)$a["id"] ?></td>
                  <td><?= htmlspecialchars($a["joc"]) ?></td>
                  <td><?= htmlspecialchars($a["durata"]) ?></td>
                  <td>
                    <form method="post" class="actions" style="margin:0;">
                      <input type="hidden" name="id" value="<?= (int)$a["id"] ?>">
                      <input class="inp" style="max-width:140px" name="pret" value="<?= htmlspecialchars($a["pret"]) ?>">
                      <button class="btn btn-save" type="submit" name="update_pret" value="1">Salvează</button>
                    </form>
                  </td>
                  <td>
                    <form method="post" style="margin:0;" onsubmit="return confirm('Ștergi acest abonament?');">
                      <input type="hidden" name="id" value="<?= (int)$a["id"] ?>">
                      <button class="btn btn-del" type="submit" name="sterge_abonament" value="1">Șterge</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- DREAPTA: ACHIZIȚII -->
    <div class="card">
      <h3 style="margin:0 0 6px;">Achiziții abonamente</h3>
      <div class="muted">Aici vezi abonamentele confirmate de utilizatori.</div>

      <div class="table-scroll" style="margin-top:10px;">
        <table class="achizitii-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Utilizator</th>
              <th>Abonament</th>
              <th>Contact</th>
              <th>Data</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!$achizitii): ?>
              <tr><td colspan="5">Nu există achiziții înregistrate (încă).</td></tr>
            <?php else: ?>
              <?php foreach ($achizitii as $c): ?>
                <tr>
                  <td><?= (int)$c["id"] ?></td>
                  <td>
                    <div class="cell-small">ID user: <?= (int)$c["id_utilizator"] ?></div>
                    <b><?= htmlspecialchars($c["nume"]) ?></b>
                  </td>
                  <td>
                    <b><?= htmlspecialchars($c["joc"]) ?></b><br>
                    <?= htmlspecialchars($c["durata"]) ?><br>
                    <span class="nowrap"><b><?= htmlspecialchars($c["pret"]) ?> RON</b></span>
                  </td>
                  <td class="cell-small">
                    <?= htmlspecialchars($c["email"]) ?><br>
                    <?= htmlspecialchars($c["telefon"]) ?>
                  </td>
                  <td class="cell-small nowrap"><?= htmlspecialchars($c["data_creare"]) ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</div>

</body>
</html>
