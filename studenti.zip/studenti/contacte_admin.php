<?php

$TIMEOUT_SECONDS = 3600; // 1 oră

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => $TIMEOUT_SECONDS,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// verificare expirare
if (isset($_SESSION['LAST_ACTIVITY']) && time() - $_SESSION['LAST_ACTIVITY'] > $TIMEOUT_SECONDS) {
    session_unset();
    session_destroy();
    header("Location: logout.php?msg=" . urlencode("Sesiunea a expirat după 1 oră de inactivitate."));
    exit;
}

// actualizare activitate
$_SESSION['LAST_ACTIVITY'] = time();

// protecție login
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html?err=" . urlencode("Trebuie să te loghezi pentru a continua."));
    exit;
}

$host = "mysql";
$dbname = "studenti";
$user = "user";
$pass = "password";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Eroare DB: " . $e->getMessage());
}

$mesaje = $pdo->query("
  SELECT id, id_utilizator, nume_complet, email, telefon, mesaj, data_trimitere
  FROM contact
  ORDER BY data_trimitere DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin - Mesaje Contact</title>
  <link rel="stylesheet" href="admin.css" />
</head>
<body>

<header class="topbar">
  <div class="top-left">
    <h1>Admin</h1>
    <nav class="admin-nav">
      <a class="nav-link" href="rezervari_admin.php">Rezervări</a>
      <a class="nav-link active" href="contacte_admin.php">Mesaje Contact</a>
      <a class="nav-link" href="abonamente_admin.php">Abonamente</a>
    </nav>
  </div>
s
  <div class="actions">
    <a class="btn" href="logout.php">Logout</a>
  </div>
</header>

<main class="container">
  <p class="meta">Total mesaje: <strong><?= count($mesaje) ?></strong></p>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>ID Utilizator</th>
          <th>Nume</th>
          <th>Email</th>
          <th>Telefon</th>
          <th>Mesaj</th>
          <th>Data</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($mesaje)): ?>
          <tr><td colspan="7">Nu există mesaje.</td></tr>
        <?php else: ?>
          <?php foreach ($mesaje as $m): ?>
            <tr>
              <td><?= htmlspecialchars($m["id"]) ?></td>
              <td><?= htmlspecialchars($m["id_utilizator"]) ?></td>
              <td><?= htmlspecialchars($m["nume_complet"]) ?></td>
              <td><?= htmlspecialchars($m["email"]) ?></td>
              <td><?= htmlspecialchars($m["telefon"]) ?></td>
              <td class="msg-cell"><?= nl2br(htmlspecialchars($m["mesaj"])) ?></td>
              <td><?= htmlspecialchars($m["data_trimitere"]) ?></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</main>

</body>
</html>
