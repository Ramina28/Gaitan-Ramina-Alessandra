<?php
session_start();

$SESSION_TIMEOUT = 3 * 24 * 60 * 60;

if (!isset($_SESSION["user_role"]) || $_SESSION["user_role"] !== "admin") {
    header("Location: login.html?err=" . urlencode("Nu ai acces. Loghează-te ca admin."));
    exit;
}

if (!isset($_SESSION["login_time"]) || (time() - $_SESSION["login_time"] > $SESSION_TIMEOUT)) {
    session_destroy();
    header("Location: login.html?err=" . urlencode("Sesiunea a expirat. Te rugăm să te loghezi din nou."));
    exit;
}

$_SESSION["login_time"] = time();

$host = "mysql";
$dbname = "studenti";
$user = "user";
$pass = "password";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Eroare DB: " . $e->getMessage());
}

$mesaje = $pdo->query("
  SELECT id, id_utilizator, nume_complet, email, telefon, mesaj, data_trimitere
  FROM contact
  ORDER BY data_trimitere DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin - Mesaje Contact</title>
  <link rel="stylesheet" href="admin.css" />
</head>
<body>

<header class="topbar">
  <div class="top-left">
    <h1>Admin</h1>
    <nav class="admin-nav">
      <a class="nav-link" href="rezervari_admin.php">Rezervări</a>
      <a class="nav-link active" href="contacte_admin.php">Mesaje Contact</a>
    </nav>
  </div>

  <div class="actions">
    <a class="btn" href="logout.php">Logout</a>
  </div>
</header>

<main class="container">
  <p class="meta">Total mesaje: <strong><?= count($mesaje) ?></strong></p>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>ID Utilizator</th>
          <th>Nume</th>
          <th>Email</th>
          <th>Telefon</th>
          <th>Mesaj</th>
          <th>Data</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($mesaje)): ?>
          <tr><td colspan="7">Nu există mesaje.</td></tr>
        <?php else: ?>
          <?php foreach ($mesaje as $m): ?>
            <tr>
              <td><?= htmlspecialchars($m["id"]) ?></td>
              <td><?= htmlspecialchars($m["id_utilizator"]) ?></td>
              <td><?= htmlspecialchars($m["nume_complet"]) ?></td>
              <td><?= htmlspecialchars($m["email"]) ?></td>
              <td><?= htmlspecialchars($m["telefon"]) ?></td>
              <td class="msg-cell"><?= nl2br(htmlspecialchars($m["mesaj"])) ?></td>
              <td><?= htmlspecialchars($m["data_trimitere"]) ?></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</main>

</body>
</html>
