<?php
session_start();

// protecție login
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html?err=" . urlencode("Trebuie să te loghezi pentru a face o rezervare."));
    exit;
}

$TIMEOUT_SECONDS = 3600;

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => $TIMEOUT_SECONDS,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

if (isset($_SESSION['LAST_ACTIVITY']) && time() - $_SESSION['LAST_ACTIVITY'] > $TIMEOUT_SECONDS) {
    session_unset();
    session_destroy();
    header("Location: logout.php?msg=" . urlencode("Sesiunea a expirat după 1 oră de inactivitate."));
    exit;
}

$_SESSION['LAST_ACTIVITY'] = time();


// DB
$host = "mysql";
$dbname = "studenti";
$user = "user";
$pass = "password";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("Eroare DB: " . $e->getMessage());
}

// ID utilizator logat
$id_utilizator = (int)$_SESSION["user_id"];

/* =========================================================
   1) ENDPOINT JSON: ore ocupate
   URL: rezervari.php?action=ocupate&joc=bowling&data=2026-01-13
   ========================================================= */
if (($_GET["action"] ?? "") === "ocupate") {
    header("Content-Type: application/json; charset=UTF-8");

    $joc  = trim($_GET["joc"] ?? "");
    $data = trim($_GET["data"] ?? "");

    if ($joc === "" || $data === "") {
        echo json_encode([]);
        exit;
    }

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) {
        http_response_code(400);
        echo json_encode(["error" => "Data invalidă"]);
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT ora
        FROM rezervari
        WHERE joc = ? AND data_rezervare = ?
        ORDER BY ora ASC
    ");
    $stmt->execute([$joc, $data]);

    $ore = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $ore = array_map(fn($t) => substr($t, 0, 5), $ore);

    echo json_encode($ore);
    exit;
}

/* =========================================================
   2) ANULARE REZERVARE (POST în același fișier)
   ========================================================= */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["anuleaza_id"])) {
    $id_rezervare = (int)($_POST["anuleaza_id"] ?? 0);

    if ($id_rezervare > 0) {
        $del = $pdo->prepare("DELETE FROM rezervari WHERE id = ? AND id_utilizator = ?");
        $del->execute([$id_rezervare, $id_utilizator]);
    }

    header("Location: rezervari.php");
    exit;
}

/* =========================================================
   3) Luăm rezervările utilizatorului
   ========================================================= */
$stmt = $pdo->prepare("
    SELECT id, joc, data_rezervare, ora, data_creare
    FROM rezervari
    WHERE id_utilizator = ?
    ORDER BY data_rezervare DESC, ora DESC
");
$stmt->execute([$id_utilizator]);
$rezervari = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rezervări - FunZone</title>
    <link rel="stylesheet" href="rezervari.css?v=5">
</head>

<body>

<button id="btnTop" title="Înapoi sus">↑</button>

<a href="PaginaPrincipala.php" class="buton-inapoi">←</a>

<h1>Rezervări Sala de Jocuri FunZone</h1>

<p>Alege jocul și data pentru rezervare. Orele ocupate vor fi blocate automat.</p>

<!-- FORMULAR REZERVARE -->
<form action="salveaza_rezervari.php" method="post" id="formRez">

    <label for="joc">Joc:</label><br>
    <select id="joc" name="joc" required>
        <option value="">--Alege jocul--</option>
        <option value="biliard">Biliard</option>
        <option value="bowling">Bowling</option>
        <option value="pingpong">Ping Pong</option>
        <option value="catarari">Cățărări</option>
        <option value="minigolf">Minigolf</option>
    </select><br><br>

    <label for="data">Data rezervării:</label><br>
    <input type="date" id="data" name="data" required><br><br>

    <label for="ora">Ora:</label><br>
    <select id="ora" name="ora" required>
        <option value="">-- alege mai întâi joc + dată --</option>
    </select>
    <p id="oraMsg" class="muted" style="margin-top:8px;"></p>
    <br>

    <input type="submit" value="Trimite rezervarea">
</form>

<hr>

<!-- REZERVĂRILE MELE -->
<section class="rezervari-card">
  <h2>Rezervările mele</h2>

  <?php if (empty($rezervari)): ?>
      <p class="muted">Nu ai nicio rezervare făcută.</p>
  <?php else: ?>
      <div class="table-scroll">
        <table class="tabel-rezervari">
          <thead>
            <tr>
              <th>Joc</th>
              <th>Data</th>
              <th>Ora</th>
              <th>Creat la</th>
              <th>Anulează</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rezervari as $r): ?>
              <tr>
                <td><?= htmlspecialchars($r["joc"]) ?></td>
                <td><?= htmlspecialchars($r["data_rezervare"]) ?></td>
                <td><?= htmlspecialchars(substr($r["ora"], 0, 5)) ?></td>
                <td><?= htmlspecialchars($r["data_creare"]) ?></td>
                <td>
                  <form method="post"
                        onsubmit="return confirm('Sigur vrei să anulezi această rezervare?');"
                        style="margin:0;">
                    <input type="hidden" name="anuleaza_id" value="<?= (int)$r["id"] ?>">
                    <button type="submit" class="btn-anuleaza" title="Anulează rezervarea">✖</button> <style>


                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
  <?php endif; ?>
</section>

<script>
  const jocEl = document.getElementById("joc");
  const dataEl = document.getElementById("data");
  const oraEl  = document.getElementById("ora");
  const oraMsg = document.getElementById("oraMsg");

  const slots = [
    "10:00","11:00","12:00","13:00","14:00","15:00",
    "16:00","17:00","18:00","19:00","20:00","21:00"
  ];

  const azi = new Date();
  const yyyy = azi.getFullYear();
  const mm = String(azi.getMonth() + 1).padStart(2, "0");
  const dd = String(azi.getDate()).padStart(2, "0");
  dataEl.min = `${yyyy}-${mm}-${dd}`;

  function setOraOptions(ocupateArr) {
    const ocupate = new Set(ocupateArr || []);
    oraEl.innerHTML = `<option value="">-- alege ora --</option>`;

    let libere = 0;
    for (const s of slots) {
      const opt = document.createElement("option");
      opt.value = s;
      opt.textContent = s;

      if (ocupate.has(s)) {
        opt.disabled = true;
        opt.textContent = `${s} (ocupat)`;
      } else {
        libere++;
      }
      oraEl.appendChild(opt);
    }

    if (jocEl.value && dataEl.value) {
      oraMsg.textContent = libere > 0
        ? `Ore libere: ${libere} / ${slots.length}`
        : `Nu mai există ore libere pentru această dată. Alege altă zi.`;
    } else {
      oraMsg.textContent = "";
    }

    oraEl.setCustomValidity(libere > 0 ? "" : "Nu există ore libere pentru ziua aleasă.");
  }

  async function refreshDisponibilitate() {
    const joc  = jocEl.value;
    const data = dataEl.value;

    if (!joc || !data) {
      oraEl.innerHTML = `<option value="">-- alege mai întâi joc + dată --</option>`;
      oraMsg.textContent = "";
      oraEl.setCustomValidity("Alege joc și dată.");
      return;
    }

    try {
      const r = await fetch(`rezervari.php?action=ocupate&joc=${encodeURIComponent(joc)}&data=${encodeURIComponent(data)}`);
      const ocupate = await r.json();
      setOraOptions(Array.isArray(ocupate) ? ocupate : []);
    } catch (e) {
      setOraOptions([]);
      oraMsg.textContent = "Nu am putut încărca orele ocupate. Încearcă din nou.";
    }
  }

  jocEl.addEventListener("change", refreshDisponibilitate);
  dataEl.addEventListener("change", refreshDisponibilitate);
</script>

<script src="main.js"></script>
</body>
</html>
