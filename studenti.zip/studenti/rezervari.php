<?php
session_start();

// protecție login
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html?err=" . urlencode("Trebuie să te loghezi pentru a face o rezervare."));
    exit;
}

// DB
$host = "mysql";
$dbname = "studenti";
$user = "user";
$pass = "password";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Eroare DB: " . $e->getMessage());
}

// ID utilizator logat
$id_utilizator = (int)$_SESSION["user_id"];

// ==========================
// Luăm rezervările utilizatorului
// ==========================
$stmt = $pdo->prepare("
    SELECT joc, data_rezervare, ora, data_creare
    FROM rezervari
    WHERE id_utilizator = ?
    ORDER BY data_rezervare DESC, ora DESC
");
$stmt->execute([$id_utilizator]);
$rezervari = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Rezervări - FunZone</title>
    <link rel="stylesheet" href="rezervari.css">
</head>

<button id="btnTop" title="Înapoi sus">↑</button>

<body>

<a href="PaginaPrincipala.php" class="buton-inapoi">←</a>

<h1>Rezervări Sala de Jocuri FunZone</h1>

<p>Alege jocul și data pentru rezervare.</p>

<!-- FORMULAR REZERVARE -->
<form action="salveaza_rezervari.php" method="post">

    <label for="joc">Joc:</label><br>
    <select id="joc" name="joc" required>
        <option value="">--Alege jocul--</option>
        <option value="biliard">Biliard</option>
        <option value="bowling">Bowling</option>
        <option value="pingpong">Ping Pong</option>
        <option value="catarari">Cățărări</option>
        <option value="minigolf">Minigolf</option>
    </select><br><br>

    <label for="data">Data rezervării:</label><br>
    <input type="date" id="data" name="data" required><br><br>

    <label for="ora">Ora:</label><br>
    <input type="time" id="ora" name="ora" required><br><br>

    <input type="submit" value="Trimite rezervarea">
</form>

<hr>

<!-- REZERVĂRILE MELE -->
<hr>

<section class="rezervari-card">
  <h2>Rezervările mele</h2>

  <?php if (empty($rezervari)): ?>
      <p class="muted">Nu ai nicio rezervare făcută.</p>
  <?php else: ?>
      <div class="table-scroll">
        <table class="tabel-rezervari">
          <thead>
            <tr>
              <th>Joc</th>
              <th>Data</th>
              <th>Ora</th>
              <th>Creat la</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rezervari as $r): ?>
              <tr>
                <td><?= htmlspecialchars($r["joc"]) ?></td>
                <td><?= htmlspecialchars($r["data_rezervare"]) ?></td>
                <td><?= htmlspecialchars($r["ora"]) ?></td>
                <td><?= htmlspecialchars($r["data_creare"]) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
  <?php endif; ?>
</section>
