<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.html?err=" . urlencode("Trebuie să te loghezi ca să faci o rezervare."));
    exit;
}

$host = "mysql";
$dbname = "studenti";
$user = "user";
$pass = "password";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Eroare conectare: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $joc  = trim($_POST["joc"] ?? "");
    $data = trim($_POST["data"] ?? "");
    $ora  = trim($_POST["ora"] ?? "");

    if ($joc === "" || $data === "" || $ora === "") {
        die("Completează toate câmpurile.");
    }

    $id_utilizator = (int)$_SESSION["user_id"];

    $stmt = $pdo->prepare("
        INSERT INTO rezervari (id_utilizator, joc, data_rezervare, ora)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$id_utilizator, $joc, $data, $ora]);

    echo "<script>alert('Rezervarea a fost salvată cu succes!'); window.location.href='rezervari.php';</script>";
    exit;
}

echo "Acces invalid.";
