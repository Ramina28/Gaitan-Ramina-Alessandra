<?php

$TIMEOUT_SECONDS = 3600; // 1 oră

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => $TIMEOUT_SECONDS,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// verificare expirare
if (isset($_SESSION['LAST_ACTIVITY']) && time() - $_SESSION['LAST_ACTIVITY'] > $TIMEOUT_SECONDS) {
    session_unset();
    session_destroy();
    header("Location: logout.php?msg=" . urlencode("Sesiunea a expirat după 1 oră de inactivitate."));
    exit;
}

// actualizare activitate
$_SESSION['LAST_ACTIVITY'] = time();

// protecție login
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html?err=" . urlencode("Trebuie să te loghezi pentru a continua."));
    exit;
}

$host = "mysql";
$dbname = "studenti";
$user = "user";
$pass = "password";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("Eroare conectare: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $joc  = trim($_POST["joc"] ?? "");
    $data = trim($_POST["data"] ?? "");
    $ora  = trim($_POST["ora"] ?? "");

    if ($joc === "" || $data === "" || $ora === "") {
        echo "<script>alert('Completează toate câmpurile.'); window.location.href='rezervari.php';</script>";
        exit;
    }

    // (opțional) validare simplă dată/oră
    // data: YYYY-MM-DD
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) {
        echo "<script>alert('Data nu este validă.'); window.location.href='rezervari.php';</script>";
        exit;
    }
    // ora: HH:MM sau HH:MM:SS
    if (!preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $ora)) {
        echo "<script>alert('Ora nu este validă.'); window.location.href='rezervari.php';</script>";
        exit;
    }

    $id_utilizator = (int)$_SESSION["user_id"];

    // ✅ Verificăm dacă slotul (joc + dată + oră) este deja rezervat
    $check = $pdo->prepare("
        SELECT COUNT(*) AS cnt
        FROM rezervari
        WHERE joc = ? AND data_rezervare = ? AND ora = ?
    ");
    $check->execute([$joc, $data, $ora]);
    $exista = (int)$check->fetchColumn();

    if ($exista > 0) {
        echo "<script>alert('Ora selectată este deja rezervată. Alege altă oră.'); window.location.href='rezervari.php';</script>";
        exit;
    }

    // ✅ Salvăm rezervarea
    $stmt = $pdo->prepare("
        INSERT INTO rezervari (id_utilizator, joc, data_rezervare, ora)
        VALUES (?, ?, ?, ?)
    ");

    try {
        $stmt->execute([$id_utilizator, $joc, $data, $ora]);
    } catch (PDOException $e) {
        // Dacă ai pus UNIQUE KEY pe (joc, data_rezervare, ora), aici prinzi dublurile și din concurență
        echo "<script>alert('Nu s-a putut salva rezervarea (posibil slot ocupat). Încearcă din nou.'); window.location.href='rezervari.php';</script>";
        exit;
    }

    echo "<script>alert('Rezervarea a fost salvată cu succes!'); window.location.href='rezervari.php';</script>";
    exit;
}

echo "Acces invalid.";
