<?php
session_start();
session_unset();
session_destroy();
header("Location: login.html?msg=" . urlencode("Te-ai delogat."));
exit;
