const detaliiDiv = document.getElementById("detalii");
const btnDetalii = document.getElementById("btnDetalii");
const dataProdusSpan = document.getElementById("dataProdus");

const LUNI_RO = [
    "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
    "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
];


detaliiDiv.classList.add("ascuns");

const dataCurenta = new Date();
const zi = dataCurenta.getDate();
const lunaText = LUNI_RO[dataCurenta.getMonth()];
const an = dataCurenta.getFullYear();

const dataFormatata = `${zi} ${lunaText} ${an}`;
dataProdusSpan.textContent = dataFormatata;


function comutaDetalii() {
    detaliiDiv.classList.toggle("ascuns");

    if (!detaliiDiv.classList.contains("ascuns")) {
        btnDetalii.textContent = "Ascunde detalii";
    } else {
        btnDetalii.textContent = "Afișează detalii";
    }
}

btnDetalii.addEventListener("click", comutaDetalii);