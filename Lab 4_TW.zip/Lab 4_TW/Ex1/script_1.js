const inputActivitate = document.getElementById("inputActivitate");
const btnAdauga = document.getElementById("btnAdauga");
const listaActivitati = document.getElementById("listaActivitati");

const LUNI_RO = [
    "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
    "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
];

function adaugaActivitate() {
    const textActivitate = inputActivitate.value.trim();

    if (textActivitate === "") {
        alert("Vă rugăm introduceți o activitate!");
        return;
    }

    const dataCurenta = new Date();
    const zi = dataCurenta.getDate();

    const lunaText = LUNI_RO[dataCurenta.getMonth()];
    const an = dataCurenta.getFullYear();

    const dataFormatata = `${zi} ${lunaText} ${an}`;
    const continutLi = `${textActivitate} – adăugată la: ${dataFormatata}`;

    const elementNouLi = document.createElement("li");
    elementNouLi.textContent = continutLi;

    listaActivitati.appendChild(elementNouLi);

    inputActivitate.value = "";
}

btnAdauga.addEventListener("click", adaugaActivitate);

inputActivitate.addEventListener("keypress", function(e) {
    if (e.key === "Enter") {
        adaugaActivitate();
    }
});